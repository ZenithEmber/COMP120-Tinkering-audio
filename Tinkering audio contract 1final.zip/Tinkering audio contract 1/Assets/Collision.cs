﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collision : MonoBehaviour
{
	AudioSource audioSource;
	void start()
	{
		audioSource = GetComponent<AudioSource>();
	}
    void OnCollisionEnter(Collision col)
	{
		if(col.gameObject.tag == "Player")
		{
			audioSource.Play();
			Destroy(col.gameObject);
		}
	}
}
