﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pitchchange : MonoBehaviour
{
	public int startingPitch = 4;
	AudioSource audioSource;
    // Start is called before the first frame update
    void Start()
    {
        audioSource = GetComponent<AudioSource>(); //finds the audio component on the cube and names it audioSource
		
		audioSource.pitch = startingPitch; //initialise the pitch
    }

    // Update is called once per frame
    void Update()
    {
        if (audioSource.pitch > 0)
		{
			audioSource.pitch -= Time.deltaTime * startingPitch;	
		}
    }
}
